acceptStuArr(stu);
    printStuArr(stu);