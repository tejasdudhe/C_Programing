#include "StructFun.c"


// struct Employee typedef emp;

struct Employee acceptStruc();
void displayStruc(struct Employee);

void acceptStuArr(struct Student[],int);
void printStuArr(struct Student[],int);

void acceptStu(struct Student *);
void printStu(struct Student *);

